// Morris.js Charts sample data for SB Admin template


$(function() {

// Area Chart
    
Morris.Area(
	{

		element: 'morris-area-chart',

		data: [
			{ period: '2016-8-17 10:00', Outlook: 5, VDI: 0, Epic: 5},
			{ period: '2016-8-17 10:30', Outlook: 6, VDI: 9, Epic: 4},  
			{ period: '2016-8-17 11:00', Outlook: 1, VDI: 1, Epic: 0}, 
			{ period: '2016-8-17 11:30', Outlook: 3, VDI: 9, Epic: 8}, 
			{ period: '2016-8-17 12:00', Outlook: 5, VDI: 1, Epic: 9}, 
			{ period: '2016-8-17 12:30', Outlook: 7, VDI: 9, Epic: 8},
			{ period: '2016-8-17 13:00', Outlook: 2, VDI: 9, Epic: 8}, 
			{ period: '2016-8-17 13:30', Outlook: 3, VDI: 6, Epic: 7}, 
			{ period: '2016-8-17 14:00', Outlook: 6, VDI: 6, Epic: 2}, 
			{ period: '2016-8-17 14:30', Outlook: 8, VDI: 1, Epic: 9}
		],

		xkey: 'period',
		ykeys: ['Outlook', 'VDI', 'Epic'],
		labels: ['Outlook', 'VDI', 'iPod Touch'],
 
		pointSize: 2,

		hideHover: 'auto',

		resize: true
    
	});



// Donut Chart
    
Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Requests",
            value: 12
        }, {
            label: "Incidents",
            value: 30
        }, {
            label: "Epic",
            value: 20
        }],
        resize: true
    });

    // Line Chart
    Morris.Line({
        // ID of the element in which to draw the chart.
        element: 'morris-line-chart',
        // Chart data records -- each entry in this array corresponds to a point on
        // the chart.
        data: [{
            d: '2012-10-01',
            Calls: 802
        }, {
            d: '2012-10-02',
            Calls: 783
        }, {
            d: '2012-10-03',
            Calls: 820
        }, {
            d: '2012-10-04',
            Calls: 839
        }, {
            d: '2012-10-05',
            Calls: 792
        }, {
            d: '2012-10-06',
            Calls: 859
        }, {
            d: '2012-10-07',
            Calls: 790
        }, {
            d: '2012-10-08',
            Calls: 1680
        }, {
            d: '2012-10-09',
            Calls: 1592
        }, {
            d: '2012-10-10',
            Calls: 1420
        }, {
            d: '2012-10-11',
            Calls: 882
        }, {
            d: '2012-10-12',
            Calls: 889
        }, {
            d: '2012-10-13',
            Calls: 819
        }, {
            d: '2012-10-14',
            Calls: 849
        }, {
            d: '2012-10-15',
            Calls: 870
        }, {
            d: '2012-10-16',
            Calls: 1063
        }, {
            d: '2012-10-17',
            Calls: 1192
        }, {
            d: '2012-10-18',
            Calls: 1224
        }, {
            d: '2012-10-19',
            Calls: 1329
        }, {
            d: '2012-10-20',
            Calls: 1329
        }, {
            d: '2012-10-21',
            Calls: 1239
        }, {
            d: '2012-10-22',
            Calls: 1190
        }, {
            d: '2012-10-23',
            Calls: 1312
        }, {
            d: '2012-10-24',
            Calls: 1293
        }, {
            d: '2012-10-25',
            Calls: 1283
        }, {
            d: '2012-10-26',
            Calls: 1248
        }, {
            d: '2012-10-27',
            Calls: 1323
        }, {
            d: '2012-10-28',
            Calls: 1390
        }, {
            d: '2012-10-29',
            Calls: 1420
        }, {
            d: '2012-10-30',
            Calls: 1529
        }, {
            d: '2012-10-31',
            Calls: 1892
        }, ],
        // The name of the data record attribute that contains x-Callss.
        xkey: 'd',
        // A list of names of data record attributes that contain y-Callss.
        ykeys: ['Calls'],
        // Labels for the ykeys -- will be displayed when you hover over the
        // chart.
        labels: ['Calls'],
        // Disables line smoothing
        smooth: false,
        resize: true
    });

    // Bar Chart
    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            device: 'Outlook',
            geekbench: 136
        }, {
            device: 'Outlook 3G',
            geekbench: 137
        }, {
            device: 'Outlook 3GS',
            geekbench: 275
        }, {
            device: 'Outlook 4',
            geekbench: 380
        }, {
            device: 'Outlook 4S',
            geekbench: 655
        }, {
            device: 'Outlook 5',
            geekbench: 1571
        }],
        xkey: 'device',
        ykeys: ['geekbench'],
        labels: ['Geekbench'],
        barRatio: 0.4,
        xLabelAngle: 35,
        hideHover: 'auto',
        resize: true
    });


});
