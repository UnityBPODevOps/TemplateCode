// Test in JS folder
$(document).ready(function()
{

	//To allow for easier hiding of elements call the input by active Button  name
	$("input[name=TechnicalTicketType]").click(function()
	{
		var $contract = $(".contract.active").html();
		if ($(this).val() == "2")
		{
			$(".incident").removeClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}else{
			$(".incident").addClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}

	});

	$("input[name=epicTicketType]").click(function()
	{
		var $contract = $(".contract.active").html();
		if ($(this).val() == "2")
		{
			$(".epicIncident").removeClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}else{
			$(".epicIncident").addClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}

	});

		$("input[name=axiaTicketType]").click(function()
		{
			var $contract = $(".contract.active").html();
			if ($(this).val() == "2")
			{
				$(".axiaIncident").removeClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			}else{
				$(".axiaIncident").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			}

		});

		$("input[name=mobTabType]").click(function()
		{
			var $contract = $(".contract.active").html();
			if ($(this).val() == "1")
			{
				$(".mobTabE").removeClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			}else
			{
				$(".mobTabE").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			}

		});

		$("input[name=vmcTicketType]").click(function()
		{
			var $contract = $(".contract.active").html();
			if ($(this).val() == "2")
			{
				$(".vmcIncident").removeClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			}else
			{
				$(".vmcIncident").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			}

		});

	$("input[name=AmedisysTicketType]").click(function()
	{
		var $contract = $(".contract.active").html();
		if ($(this).val() == "2")
		{
			$(".incident").removeClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}else
		{
			$(".incident").addClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}

	});

	$("input[name=amedcTicketType]").click(function()
	{
		var $contract = $(".contract.active").html();
		if ($(this).val() == "2")
		{
			$(".amedcIncident").removeClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}else
		{
			$(".amedcIncident").addClass("hidden");
			$("textarea[class*='"+ $contract +"']").expanding();
		}

	});

	$("input[name=presbyterianTicketType]").click(function()
	{
		var $contract = $(".contract.active").html();
//		console.log("Value "+ $(this).val());
		switch ($(this).val())
		{
			case '1':
				$(".incident").addClass("hidden");
				$(".printer").addClass("hidden");
				$(".careManager").addClass("hidden");
				$(".dataLoss").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			break;
			case '2':
				$(".incident").removeClass("hidden");
				$(".printer").addClass("hidden");
				$(".careManager").addClass("hidden");
				$(".dataLoss").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			break;
			case '3':
				$(".incident").removeClass("hidden");
				$(".printer").removeClass("hidden");
				$(".careManager").addClass("hidden");
				$(".dataLoss").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			break;
			case '4':
				$(".incident").addClass("hidden");
				$(".printer").addClass("hidden");
				$(".careManager").removeClass("hidden");
				$(".dataLoss").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			break;
			case '5':
				$(".incident").addClass("hidden");
				$(".printer").addClass("hidden");
				$(".careManager").addClass("hidden");
				$(".dataLoss").removeClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			break;
			default:
				$(".incident").addClass("hidden");
				$(".printer").addClass("hidden");
				$(".careManager").addClass("hidden");
				$(".dataLoss").addClass("hidden");
				$("textarea[class*='"+ $contract +"']").expanding();
			break;
		}

	});

// Add application to drop downs
	$.each($presApps, function ( i )
	{
		$("#PresbyterianApplication").append($("<option>", {value: $presApps[i].appID, text: $presApps[i].application}));
	});

	$.each($amedisysApps, function ( i )
	{
		$("#AmedisysApplication").append($("<option>", {value: $amedisysApps[i].appID, text: $amedisysApps[i].application}));
	});

	$.each($amedcApps, function ( i )
	{
		var $text = $amedcApps[i].application + " - " + $amedcApps[i].callReason;
		$("#amedcApp").append($("<option>", {value: $amedcApps[i].appID, text: $text}));
	});

	$("#amedcApp").change(function()
	{
		var $option = "";
		var $resolutionSteps = "";
		$template = $("#amedcApp").val();
		if ($("#amedcApp").val() !="" && $("#amedcApp").val() !=3  )
		{
			$(".amedcAppOther").addClass("hidden");
			$steps = $amedcApps[$template].resolutionSteps;
			x = 0;
			for (x in $steps)
			{
				$option += '<div class="checkbox">\n<label for="steps-'+ x +'">\n<input name="steps" id="steps-'+ x +'" value="'+ x +'" type="checkbox">';
				$option +=  $steps[x] + "\n</label>\n</div>\n</div>";
				$("#amedcSteps").html($option);
				x ++;
			}

			$("#stepsTaken").modal("show");
			$("#amedcSummaryIssue").val($amedcApps[$template].summary);
			$("#amedcReason").val($amedcApps[$template].callReason);
		}else if ($("#amedcApp").val() ==3 )
		{
			$(".amedcAppOther").removeClass("hidden");
		}
	});

	$("#stepsTaken").on('hidden.bs.modal', function (e)
	{
		var $option = "";
		var $resolutionSteps = "";
		$template = $("#amedcApp").val();
		$("#amedcTSteps").val("");
		$("amedcReason").val("");
		if ($("#amedcApp").val() !="")
		{
			$steps = $amedcApps[$template].resolutionSteps;
			x = 0;
			for (x in $steps)
			{
				if ($("#steps-"+x+"").prop('checked'))
				{
					$resolutionSteps += $steps[x] + "\n";
				}
			}
			$("#amedcTSteps").val($resolutionSteps);
			$("#amedcReason").val($amedcApps[$template].callReason);

		}
		AmedCSummary();
	})

	$("#PresbyterianApplication").change(function()
	{
		if ($("#PresbyterianApplication").val() !="")
		{
			$("#presbyterianReason").val($presApps[$("#PresbyterianApplication").val()].callReason);
			$("#presbyterianSteps").val($presApps[$("#PresbyterianApplication").val()].resolutionSteps);
		}
	});

	$("#AmedisysApplication").change(function()
	{
		if ($("#AmedisysApplication").val() !="")
		{
			$("#AmedisysSummaryIssue").val($amedisysApps[$("#AmedisysApplication").val()].callReason);
			$("#AmedisysTroubleshooting").val($amedisysApps[$("#AmedisysApplication").val()].resolutionSteps);
		}
	});

	$("#patientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".patient").removeClass("hidden")
		else $(".patient").addClass("hidden");
	});

	$("#epicPatientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".epicPatient").removeClass("hidden")
		else $(".epicPatient").addClass("hidden");
	});

	$("#axiaPatientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".axiaPatient").removeClass("hidden")
		else $(".axiaPatient").addClass("hidden");
	});

	$("#amedcPatientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".amedcPatient").removeClass("hidden")
		else $(".amedcPatient").addClass("hidden");
	});

	$("#vmcPatientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".vmcPatient").removeClass("hidden")
		else $(".vmcPatient").addClass("hidden");
	});

	$("#vnsnyPatientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".vnsnyPatient").removeClass("hidden")
		else $(".vnsnyPatient").addClass("hidden");
	});

	$("#ghgPatientBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".ghgPatient").removeClass("hidden")
		else $(".ghgPatient").addClass("hidden");
	});


// VMC MyChart/TeleMed & Internal Support

	$("#vmcMyChart").click(function()
	{
		if ($(this).prop("checked") == true ) $(".vmcMyChart").removeClass("hidden")
		else $(".vmcMyChart").addClass("hidden");
	});

	$("#vmcInternal").click(function()
	{
		if ($(this).prop("checked") == true ) $(".vmcInternal").removeClass("hidden")
		else $(".vmcInternal").addClass("hidden");
	});

	$(document).ready(function () {
	    $(".vmcMyChart").hide();
	    $("#vmcMyChart").click(function () {
	        $(".vmcMyChart").show();
	    });
	    $("#vmcInternal").click(function () {
	        $(".vmcMyChart").hide();
	    });
	});

	$(document).ready(function () {
	    $(".vmcInternal").hide();
	    $("#vmcInternal").click(function () {
	        $(".vmcInternal").show();
	    });
	    $("#vmcMyChart").click(function () {
	        $(".vmcInternal").hide();
	    });
	});

	$("#vmcTechPHI").click(function()
	{
		if ($(this).prop("checked") == true ) $(".vmcTechPHI").removeClass("hidden")
		else $(".vmcTechPHI").addClass("hidden");
	});

// Graham Expanding Fields

	$("#prefPhone").click(function()
	{
		if ($(this).prop("checked") == true ) $(".prefPhone").removeClass("hidden")
		else $(".prefPhone").addClass("hidden");
	});

	$("#prefEmail").click(function()
	{
		if ($(this).prop("checked") == true ) $(".prefEmail").removeClass("hidden")
		else $(".prefEmail").addClass("hidden");
	});

	$(document).ready(function () {
	    $(".prefPhone").hide();
	    $("#prefPhone").click(function () {
	        $(".prefPhone").show();
	    });
	    $("#prefEmail").click(function () {
	        $(".prefPhone").hide();
	    });
	});

	$(document).ready(function () {
	    $(".prefEmail").hide();
	    $("#prefEmail").click(function () {
	        $(".prefEmail").show();
	    });
	    $("#prefPhone").click(function () {
	        $(".prefEmail").hide();
	    });
	});

// Printer Issues

	$("#epicPrinterIssue").click(function()
	{
		var $contract = $(".contract.active").html();
		if ($(this).prop("checked") == true ) $("."+ $contract +"PrinterRequired").removeClass("hidden")
		else $("."+ $contract +"PrinterRequired").addClass("hidden");
	});

	$("#printerIssue").click(function()
	{
		var $contract = $(".contract.active").html();
		if ($(this).prop("checked") == true ) $("." + $contract + ".printer").removeClass("hidden")
		else $("." + $contract + ".printer").addClass("hidden");
	});

	$("#passwordResetBox").click(function()
	{
		if ($(this).prop("checked") == true ) $(".password").removeClass("hidden")
		else $(".password").addClass("hidden");
	});

	$("#phiBox").click(function()
	{
		if ($("#phiBox").prop('checked'))
		{
			$(".phi").removeClass("hidden");
		}else
		{
			$(".phi").addClass("hidden");
		}
	});

	$("#amedisysLocation").blur(function()
	{
		AmedisysSummary();
	});
	$("#AmedisysSummaryIssue").blur(function()
	{
		AmedisysSummary();
	});
	$("#amedisysApplicationOther").blur(function()
	{
		AmedisysSummary();
	});

	$("#amedisysApplicationAcademy").blur(function()
	{
		AmedisysSummary();
	});

	$("input[name=AmedisysHCH]").click(function()
	{
		AmedisysSummary();
	});
	$("input[name=AmedisysDevice]").click(function()
	{
		AmedisysSummary();
	});
	$("#AmedisysApplication").change(function()
	{
		amedisysApplication();
	});
	$("#amedcLocation").blur(function()
	{
		amedcSummary();
	});
	$("#amedcSummaryIssue").blur(function()
	{
		amedcSummary();
	});
	$("#amedcAppOther").blur(function()
	{
		amedcSummary();
	});
	$("input[name='amedcHCH']").click(function()
	{
		amedcSummary();
	});

	$("#mobLocation").blur(function()
	{
		mobilitySummary();
	});
	$("input[name='mobDept']").click(function()
	{
		mobilitySummary();
	});
	$("#mobSumLine").blur(function()
	{
		mobilitySummary();
	});
	$("#mobSum").blur(function()
	{
		mobilitySummary();
	});
	$("input[name='mobTag']").click(function()
	{
		mobilitySummary();
	});

	$("#axiaPrinterIssue").click(function()
		{
			var $contract = $(".contract.active").html();
			if ($(this).prop("checked") == true ) $("."+ $contract +"PrinterRequired").removeClass("hidden")
			else $("."+ $contract +"PrinterRequired").addClass("hidden");
		});

	$("#user").blur(function()
	{
		//regex [(].*[)]
		var $name = $(this).val();
		var $start = $name.indexOf("(")+1;
		var $length = $name.indexOf(")")- $start;
		var $user = $name.substr($start , $length);
		if ($user != "")
		{
			$(this).val($name.slice(0, $name.indexOf("(")-1));
			$("#networkID").val($user);
		}
	});

	$(".contract").click(function()
	{
		var $contract = $(this).html();
		console.log($contract );
		$(".form-horizontal").addClass("hidden");
		$("."+ $contract ).removeClass("hidden");
		$(".contract").removeClass("active");
		$(this).addClass("active");
		$("textarea[class*='"+ $contract +"']").expanding();
	});

	$("#application").change(function() { passwordReset()});

	$("#ssnVerified").prop('checked', false);

	$("#PresbyterianVerification").click(function()
	{
		if ($(this).prop("checked"))
		{
			$(".PresbyterianVerification").removeClass("hidden");
		}else
		{
			$(".PresbyterianVerification").addClass("hidden");
		}
	});


	$("#category").autocomplete(
	{
		minLength: 3,
		source: [ "Hardware", "Software", "Telephone", "Peripheral"]
	});

	$("input[name=HoneywellKB]").click(function()
	{
		if ($(this).val() == "1")
		{
			$(".HoneywellSource").addClass("hidden");
			$(".HoneywellKBUsed").removeClass("hidden");
		}else
		{
			$(".HoneywellKBUsed").addClass("hidden");
			$(".HoneywellSource").removeClass("hidden");
		}
	});

	$("input[name=AerojetKB]").click(function()
	{
		if ($(this).val() == "1")
		{
			$(".AerojetSource").addClass("hidden");
			$(".AerojetKBUsed").removeClass("hidden");
		}else
		{
			$(".AerojetKBUsed").addClass("hidden");
			$(".AerojetSource").removeClass("hidden");
		}
	});

	$("#HoneywellVerified").click(function()
	{
		if ($("#HoneywellVerified").prop('checked'))
		{
			$(".verified").addClass("hidden");
		}else
		{
			$(".verified").removeClass("hidden");
		}
	});


});



function resetForm()
{
	var $contract = $(".contract.active").html();
	console.log($contract);
	$("input[class*='"+ $contract + "']").val("");
	$("textarea[class*='"+ $contract + "']").val("");

	$("textarea[class*='"+ $contract + "']").keyup(13);

	$("#request").click();
	if ($("#epicPatientBox").prop('checked')) $("#epicPatientBox").click();
	if ($("#epicPrinterIssue").prop('checked')) $("#epicPrinterIssue").click();
	if ($("#printerIssue").prop('checked')) $("#printerIssue").click();
	if ($("#patientBox").prop('checked')) $("#patientBox").click();
	if ($("#passwordResetBox").prop('checked')) $("#passwordResetBox").click();
	if ($("#HoneywellVerified").prop('checked')) $("#HoneywellVerified").click();
	if ($("#HoneywellKB-0").prop('checked')) $("#HoneywellKB-1").click();
	if ($("#HoneywellKBUsed").prop('checked')) $("#HoneywellKBUsed").click();
	if ($("#axiaPatientBox").prop('checked')) $("#axiaPatientBox").click();
	if ($("#axiaPrinterIssue").prop('checked')) $("#axiaPrinterIssue").click();
	if ($("#Alab").prop('checked')) $("#Alab").click();
	if ($("#GRNWY").prop('checked')) $("#GRNWY").click();
	if ($("#eCW10E").prop('checked')) $("#eCW10E").click();
	if ($("#eCWVB").prop('checked')) $("#eCWVB").click();
	if ($("#O365").prop('checked')) $("#O365").click();
	if ($("#eCWNONE").prop('checked')) $("#eCWNONE").click();
	if ($("#eCWEE").prop('checked')) $("#eCWEE").click();
	$('input[name=eCWEE]').attr('checked',false);
	if ($("#vnsnyVerified").prop('checked')) $("#vnsnyVerified").click();
	if ($("#amedcVerified").prop('checked')) $("#amedcVerified").click();
	if ($("#mobQPMYes").prop('checked')) $("#mobQPMNo").click();
	if ($("#mobNALYes").prop('checked')) $("#mobNALNo").click();
	if ($("#mobFDRYes").prop('checked')) $("#mobFDRNo").click();
	if ($("#mobHCHBYes").prop('checked')) $("#mobHCHBNo").click();
	if ($("#mobSerYes").prop('checked')) $("#mobSerNo").click();
	if ($("#mobVerYes").prop('checked')) $("#mobVerNo").click();
	if ($("#mobRetYes").prop('checked')) $("#mobRetNo").click();
	if ($("#mobConYes").prop('checked')) $("#mobConNo").click();
	if ($("#mobMaasYes").prop('checked')) $("#mobMaasNo").click();
	if ($("#mobConfigYes").prop('checked')) $("#mobConfigNo").click();
	if ($("#mobBatYes").prop('checked')) $("#mobBatNo").click();
	if ($("#mobTabE").prop('checked')) $("#mobTab4").click();
	if ($("#verName").prop('checked')) $("#verName").click();
	if ($("#verDOB").prop('checked')) $("#verDOB").click();
	if ($("#verSSN").prop('checked')) $("#verSSN").click();
	if ($("#verAddress").prop('checked')) $("#verAddress").click();
	if ($("#verMember").prop('checked')) $("#verMember").click();
	if ($("#AerojetVerified").prop('checked')) $("#AerojetVerified").click();
	if ($("#AerojetKB-0").prop('checked')) $("#AerojetKB-1").click();
	if ($("#AerojetKBUsed").prop('checked')) $("#AerojetKBUsed").click();
	if ($("#vmcTechPHI").prop('checked')) $("#vmcTechPHI").click();
	if ($("#vmcPatientBox").prop('checked')) $("#vmcPatientBox").click();
	if ($("#vmcPatVer").prop('checked')) $("#vmcPatVer").click();

	$("textarea[class*='"+ $contract +"']").expanding();
	if ($contract = "Code C") $("#codeCEmail").addClass("disabled");

	if ($contract = "Amedisys") AmedisysReset();
}


function generate()
{
	var $contract = $(".contract.active").html();
	eval($contract+"()");
	console.log($contract);
	document.execCommand("copy");
}

//The followng fucntion are called fron contract name  $contract = $(".contract.active").html();
//These are the only JS functions that need to be updated to edit and add contract
// if adding contract use the name for the button as the function name

function Technical()
{
	var infoMissing = false;
	var $alertMessage = "";
	var $user = $("#user").val();
	var $networkID = $("#networkID").val();
	var $contactNum = $("#contactNum").val();
	var $altNum = $("#altNum").val();
	var $hostname = $("#hostName").val();
	var $vdiPool = $("#vdiPool").val();
	var $floor = $("#floor").val();
	var $location = $("#location").val();
	var $locationDetails = $("#locationDetails").val();
	var $department = $("#department").val();
	var $issue = $("#issue").val();
	var $steps = $("#steps").val();
	var $queue = $("#queue").val();
	var $printerIP = $("#printerIP").val();
	var $affected = $("#affected").val();
	var $start = $("#start").val();
	var $worked = $("#worked").val();
	var $changed = $("#changed").val();
	var $errorMessage = $("#errorMessage").val();
	var $priority = $("#priority").val();
	var	$kb = $("#kb").val();
	var	$phoneModel = $("#phoneModel").val();
	var $phone = "";
	var $contract = $(".contract.active").html();
	var	$mrn = $("input[name=mrn][class*="+ $contract +"]").val();
	var	$dob = $("input[name=accession][class*="+ $contract +"]").val();
	var	$caseID = $("input[name=patientName][class*="+ $contract +"]").val();
	var	$UMID = $("input[name=studyDate][class*="+ $contract +"]").val();

	if ($user == "" || $networkID =="") $alertMessage += "User name and Network id are required\r\n";
	if ($hostname == "" && $printerIP =="" && $queue =="" && $phone =="") $alertMessage +=  "Device info is required\r\n";
	var $template = "-------------User Info-------------------\r\n"
	if ($user != "" ) $template += "Name: " + $user + " \r\n";
	$template += "User ID: " + $networkID + " \r\nPhone: " + $contactNum + " \r\nAlt Phone: " + $altNum +"\r\n";
	if ($hostname != "") $template += "Device/Phone Impacted: " + $hostname +" \r\n";
	if ($vdiPool != "") $template += "VDI Pool: " + $vdiPool +" \r\n";
	if ($phoneModel !="") $template += "Phone Model: " + $phoneModel + " \r\n";
	if ($queue !="") $template += "Printer NT Name: " + $queue + "\r\n";
	if ($printerIP !="") $template += "Device/Printer IP: " + $printerIP + "\r\n";
	if ($location !="" || $floor !="" || $locationDetails !="" ) $template += "Location (Floor/Suite/Room): ";
	if ($location !="") $template += $location;
	if ($floor !="") $template += " " + $floor;
	if ($locationDetails !="") $template += " " + $locationDetails;
	if ($location !="" || $floor !="" || $locationDetails !="" ) $template += "\r\n"
	if ($department !="") $template += "Department: " + $department + "\r\n";
	$template += "\r\n";
	$template += "-------------Reason for Call-------------\r\n" +  $issue +"\r\n\r\n";
	$template += "-------------Steps Taken to Resolve------\r\n" + $steps + "\r\n\r\n";

	if ($("#patientBox").prop('checked'))
	{
		$template += "-------------Patient Information---------\r\n"
		if ($mrn != "") $template += "MRN : " + $mrn + " \r\n";
		if ($dob != "") $template += "Accession : " + $dob + " \r\n";
		if ($caseID != "") $template += "Patient Name : " + $caseID + " \r\n";
		if ($UMID != "") $template += "Date of Study : " + $UMID + " \r\n"
		$template += "\r\n";

	}
	if ($("input[name=TechnicalTicketType]:checked").val() == "2")
	{
		$template += "-------------Incident Questions-----------\r\n\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + " \r\n";
		if ($priority !="") $template += "Priority reason: " + $priority + "\r\n";
		if ($kb !="") $template += "KB:" +  $kb + " \r\n";

		if ($networkID =="" || $location =="" || $floor =="" || $user =="" || $hostname =="" )
		{
			alert("Name, user ID, Contact #, Location, Floor, and device name are required for ticket ");
			$("#template").val("");
		}else
		{
			$("#template").val($template);
			$("#template").expanding('refresh');
			$("#template").select();
		}


	}else
	{
		if ($alertMessage !=  "") alert($alertMessage);

		$("#template").val($template);
		$("#template").expanding('refresh');
		$("#template").select();

	}
}

function Epic()
{
	var $infoMissing = false;
	var $contract = $(".contract.active").html();
	var $userName = $("#epicUserName").val();
	var $phoneNum = $("#epicPhoneNum").val();
	var $altPhone = $("#epicAltNum").val();
	var $userID = $("#epicUserID").val();
	var $role = $("#epicRole").val();
	var $location = $("#epicLocation").val();
	var $pcid = $("#epicpcid").val();
	var $dept = $("#loginDept").val();
	var $reason = $("#epicreason").val();
	var $steps = $("#epicsteps").val();
	var $printerID = $("#epicPrinterID").val();
	var $printerLocation = $("#epicPrinterLocation").val();
	var $printerMake = $("#epicPrinterMake").val();
	var $printerLocationID = $("#epicPrinterLocationID").val();
	var $printerIP = $("#epicPrinterIP").val();
	var $affected = $("#epicAffected").val();
	var $start = $("#epicStart").val();
	var $worked = $("#epicWorked").val();
	var $changed = $("#epicChanged").val();
	var $errorMessage = $("#epicErrorMessage").val();
	var	$kb = $("#epicKb").val();
	var	$mrn = $("input[name=mrn][class*="+ $contract +"]").val();
	var	$csn = $("input[name=csn][class*="+ $contract +"]").val();
	var	$dob = $("input[name=dob][class*="+ $contract +"]").val();
	var	$patientName = $("input[name=patientName][class*="+ $contract +"]").val();
	var	$order = $("input[name=order][class*="+ $contract +"]").val();
	var	$accession = $("input[name=accession][class*="+ $contract +"]").val();
	var	$studyDate = $("input[name=studyDate][class*="+ $contract +"]").val();
//	var	$caseID = $("input[name=caseID][class*="+ $contract +"]").val();
//	var	$UMID = $("input[name=UMID][class*="+ $contract +"]").val();
	var $phi="";

	var $template = "User Name: " + $userName + "\r\n";
	$template += "Phone Number: " + $phoneNum + "\r\n";
	$template += "Alt. Phone Number: " + $altPhone + "\r\n";
	$template += "User ID: " + $userID + "\r\n";
	$template += "Role: " + $role + "\r\n\r\n";
	$template += "Location: " + $location + "\r\n\r\n";
	$template += "PCID: " + $pcid + "\r\n";
	$template += "Login Dept: " + $dept + "\r\n";
	$template += "--------------------------Reason for Call-----------------------------\r\n\r\n" + $reason + "\r\n";
	$template += "--------------------------Steps to Resolve---------------------------\r\n\r\n" + $steps + "\r\n";

	if ($printerID !="" || $printerLocation != "" || $printerMake != "" || $printerLocationID !="" || $printerIP != "" )
	{
		$template += "-------------------------Printer Information-------------------------\r\n\r\n";
	}

	if ($printerID !="") $template += "Epic Printer ID: " + $printerID + "\r\n";
	if ($printerLocation !="") $template += "Printer Location: " + $printerLocation + "\r\n";
	if ($printerMake !="") $template += "Printer Make & Model: " + $printerMake + "\r\n";
	if ($printerLocationID !="") $template += "Printer Location ID: " + $printerLocationID + "\r\n";
	if ($printerIP !="") $template += "Printer IP Address: " + $printerIP + "\r\n";

	if ($("input[name=epicTicketType]:checked").val() == "2")
	{
		$template += "------------Required Questions:-----------\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + " \r\n";
		if ($kb !="") $template += "KB:" +  $kb + " \r\n";

	}

	if ($("#epicPatientBox").prop('checked'))
	{
		if ($mrn != "") $phi += "MRN : " + $mrn + " \r\n";
		if ($csn != "") $phi += "CSN : " + $csn + " \r\n";
		if ($dob != "") $phi += "DOB : " + $dob + " \r\n";
		if ($patientName != "") $phi += "Patient Name : " + $patientName + " \r\n";
		if ($order != "") $phi += "Order # : " + $order + " \r\n";
		if ($accession != "") $phi += "Accession : " + $accession + " \r\n";
		if ($studyDate != "") $phi += "Date of Study : " + $studyDate + " \r\n";
//		if ($caseID != "") $phi += "Case ID : " + $caseID + " \r\n";
//		if ($UMID != "") $phi += "UM ID : " + $UMID + " \r\n"

	}

	if($("#printerIssue").prop('checked'))
	{
		if ($printerID  == "" || $printerLocation == ""  || $printerMake == ""  || $printerIP == ""  )
		$infoMissing = "Required Printer info missing"
	}

	if ($("#phiBox").prop('checked'))
	{
		if ($mrn != "") $phi += "MRN : " + $mrn + " \r\n";
		if ($dob != "") $phi += "DOB : " + $dob + " \r\n";
//		if ($caseID != "") $phi += "Case ID : " + $caseID + " \r\n";
//		if ($UMID != "") $phi += "UM ID : " + $UMID + " \r\n"

	}

	if ($infoMissing != "") alert($infoMissing);

	$("#epicPhiBox").val($phi);
	$("#epicTemplate").val($template);
	$("#epicTemplate").select();
}

function Axia()
{
	var $infoMissing = false;
	var $contract = $(".contract.active").html();
	var $userName = $("#axiaUserName").val();
	var $phoneNum = $("#axiaPhoneNum").val();
	var $altPhone = $("#axiaAltNum").val();
	var $role = $("#axiaRole").val();
	var $location = $("#axiaLocation").val();
	var $pcid = $("#axiaAsset").val();
	var $reason = $("#axiaReason").val();
	var $steps = $("#axiaSteps").val();
	var $printerID = $("#axiaPrinterID").val();
	var $printerLocation = $("#axiaPrinterLocation").val();
	var $printerMake = $("#axiaPrinterMake").val();
	var $printerLocationID = $("#axiaPrinterLocationID").val();
	var $printerIP = $("#axiaPrinterIP").val();
	var $affected = $("#axiaAffected").val();
	var $start = $("#axiaStart").val();
	var $worked = $("#axiaWorked").val();
	var $changed = $("#axiaChanged").val();
	var $errorMessage = $("#axiaErrorMessage").val();
	var	$kb = $("#axiaKb").val();
	var	$mrn = $("input[name=mrn][class*="+ $contract +"]").val();
	var	$csn = $("input[name=csn][class*="+ $contract +"]").val();
	var	$dob = $("input[name=dob][class*="+ $contract +"]").val();
	var	$patientName = $("input[name=patientName][class*="+ $contract +"]").val();
	var	$provider = $("input[name=provider][class*="+ $contract +"]").val();
	var	$facility = $("input[name=facility][class*="+ $contract +"]").val();
	var	$studyDate = $("input[name=studyDate][class*="+ $contract +"]").val();
	var	$caseID = $("input[name=caseID][class*="+ $contract +"]").val();
	var	$UMID = $("input[name=UMID][class*="+ $contract +"]").val();
	var $phi="";

	var $template = "User Name: " + $userName + "\r\n";
	$template += "Phone Number: " + $phoneNum + "\r\n";
	$template += "Alt. Phone Number: " + $altPhone + "\r\n";
	$template += "Role: " + $role + "\r\n";
	$template += "Location: " + $location + "\r\n";
	$template += "Computer/Tablet Name: " + $pcid + "\r\n\r\n";
	$template += "--------------------------Reason for Call-----------------------------\r\n\r\n" + $reason + "\r\n";
	$template += "--------------------------Steps to Resolve---------------------------\r\n\r\n" + $steps + "\r\n";
	if ($("#Alab").prop('checked')) $template += "Lab: Yes \r\n";
	else $template += "Lab: No \r\n"
	if ($("#GRNWY").prop('checked')) $template += "Greenway: Yes \r\n";
	else $template += "Greenway: No \r\n"
	if ($("#eCW10E").prop('checked')) $template += "eCW 10e: Yes \r\n";
	else $template += "eCW 10e: No \r\n"
	if ($("#eCWVB").prop('checked')) $template += "eCW VB: Yes \r\n";
	else $template += "eCW VB: No \r\n"
	if ($("#O365").prop('checked')) $template += "Office 365: Yes \r\n";
	else $template += "Office 365: No \r\n"
	if ($("#eCWNONE").prop('checked')) $template += " \r\n";
	else $template += " \r\n"

	if ($printerID !="" || $printerLocation != "" || $printerMake != "" || $printerLocationID !="" || $printerIP != "" )
	{
		$template += "-------------------------Printer Information-------------------------\r\n\r\n";
	}

	if ($printerID !="") $template += "Axia Printer ID: " + $printerID + "\r\n";
	if ($printerLocation !="") $template += "Printer Location: " + $printerLocation + "\r\n";
	if ($printerMake !="") $template += "Printer Make & Model: " + $printerMake + "\r\n";
	//if ($printerLocationID !="") $template += "Printer Location ID: " + $printerLocationID + "\r\n";
	if ($printerIP !="") $template += "Printer IP Address: " + $printerIP + "\r\n";

	if ($("input[name=axiaTicketType]:checked").val() == "2")
	{
		$template += "------------Required Questions:-----------\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + " \r\n";
		if ($kb !="") $template += "KB:" +  $kb + " \r\n";

	}

	if ($("#axiaPatientBox").prop('checked'))
	{
		if ($mrn != "") $phi += "Account No.: " + $mrn + " \r\n";
		if ($csn != "") $phi += "Encounter Date: " + $csn + " \r\n";
		if ($dob != "") $phi += "DOB: " + $dob + " \r\n";
		if ($patientName != "") $phi += "Patient Name: " + $patientName + " \r\n";
		if ($provider != "") $phi += "Provider Name: " + $provider + " \r\n";
		if ($facility != "") $phi += "Facility Name: " + $facility + " \r\n";
		//if ($studyDate != "") $phi += "Date of Study: " + $studyDate + " \r\n";
		//if ($caseID != "") $phi += "Case ID : " + $caseID + " \r\n";
		//if ($UMID != "") $phi += "UM ID : " + $UMID + " \r\n"

	}

	if($("#printerIssue").prop('checked'))
	{
		if ($printerID  == "" || $printerLocation == ""  || $printerMake == ""  || $printerIP == ""  )
		$infoMissing = "Required Printer info missing"
	}

	if ($("#phiBox").prop('checked'))
	{
		if ($mrn != "") $phi += "MRN : " + $mrn + " \r\n";
		if ($dob != "") $phi += "DOB : " + $dob + " \r\n";
		if ($caseID != "") $phi += "Case ID : " + $caseID + " \r\n";
		if ($UMID != "") $phi += "UM ID : " + $UMID + " \r\n"

	}

	if ($infoMissing != "") alert($infoMissing);

	$("#axiaPhiBox").val($phi);
	$("#axiaTemplate").val($template);
	$("#axiaTemplate").select();
}

function Valley()
{
	var $infoMissing = "";
	var $contract = $(".contract.active").html();
	var $userName = $("#vmcUID2").val();
	var	$patName = $("#vmcPatient").val();
	var $phoneNum = $("#vmcPhone").val();
	var $altPhone = $("#vmcAltPhone").val();
	var $uID = $("#vmcUID").val();
	var $knowledge = $("#vmcKB").val();
	var $start = $("#vmcWDTS").val();
	var $worked = $("#vmcDTWB").val();
	var $changed = $("#vmcHACS").val();
	var $errorMessage = $("#vmcLAEM").val();
	var $phoneNum2 = $("#vmcPhone2").val();
	var $altPhone2 = $("#vmcAltPhone2").val();
	var $location = $("#vmcLoc").val();
	var $pcid = $("#vmcPCID").val();
	var $application = $("#vmcApp").val();
	var $knowledge2 = $("#vmcKB2").val();
	var $reason = $("#vmcReason").val();
	var $steps = $("#vmcSteps").val();
	var $myChart = $("#MyChart")
	var	$mrn = $("input[name=mrn][class*="+ $contract +"]").val();
	var	$csn = $("input[name=csn][class*="+ $contract +"]").val();
	var	$dob = $("input[name=dob][class*="+ $contract +"]").val();
	var	$patientName = $("input[name=patientName][class*="+ $contract +"]").val();
	var	$order = $("input[name=order][class*="+ $contract +"]").val();
	var	$accession = $("input[name=accession][class*="+ $contract +"]").val();
	var	$studyDate = $("input[name=studyDate][class*="+ $contract +"]").val();
	var	$mcase = $("input[name=mCase][class*="+ $contract +"]").val();
	var $umid = $("input[name=umid][class*="+ $contract +"]").val();
	var $techPatName = $("input[name=vmcPatName][class*="+ $contract +"]").val();
	var $techMRN = $("input[name=vmcTechMRN][class*="+ $contract +"]").val();
	var $techDOB = $("input[name=vmcTechDOB][class*="+ $contract +"]").val();
	var $techSSN = $("input[name=vmcTechSSN][class*="+ $contract +"]").val();
	var $techApp = $("input[name=vmcTechApp][class*="+ $contract +"]").val();
	var $vmcAffecting = $("#vmcAffected").val();
	var $vmcStart = $("#vmcStart").val();
	var $vmcBefore = $("#vmcBefore").val();
	var $vmcChanged = $("#vmcChanged").val();
	var $vmcError = $("#vmcErrorMessage").val();
	var $phi="";

	if ($("#vmcMyChart").prop('checked'))
		{
			$template = "Patient Name: " + $patName + "\r\n";
			$template += "Phone Number: " + $phoneNum + "\r\n";
			$template += "Alt. Phone Number: " + $altPhone + "\r\n";
			$template += "User ID: " + $uID + "\r\n";
			$template += "KB Used: " + $knowledge + "\r\n";
			$template += "When did this start? " + $start + "\r\n";
			$template += "Did this work before? " + $worked + "\r\n";
			$template += "Has anything changed since it last worked? " + $changed + "\r\n";
			$template += "List any error messages: " + $errorMessage + "\r\n";
	}

	if ($("#vmcInternal").prop('checked'))
		{
			$template = "--------------------------User Information----------------------------\r\n";
			if ($phoneNum2 != "") $template += "Phone Number: " + $phoneNum2 + " \r\n"
			else $infoMissing += "Phone Number Required! ";
			//$template += "Phone Number: " + $phoneNum2 + "\r\n";
			if ($altPhone2 != "") $template += "Alt. Phone Number: " + $altPhone2 + " \r\n"
			else $infoMissing += "Alt. Phone Number Required! ";
			//$template += "Alt. Phone Number: " + $altPhone2 + "\r\n";
			if ($userName != "") $template += "First & Last Name: " + $userName + " \r\n"
			else $infoMissing += "User ID Required! ";
			//$template += "User ID: " + $userName + "\r\n";
			if ($location != "") $template += "Current location: " + $location + " \r\n\r\n"
			else $infoMissing += "Current Location Required! ";
			//$template += "Current Location: " + $location + "\r\n\r\n";
			if ($pcid != "") $template += "Computer Name: " + $pcid + " \r\n"
			else $template += "";
			//$template += "Computer Name: " + $pcid + "\r\n";
			//if ($application != "") $template += "Application: " + $application + " \r\n";
			//if ($knowledge2 != "") $template += "KB Used: " + $knowledge2 + " \r\n";
	}

	$template += "--------------------------Reason for Call-----------------------------\r\n\r\n" + $reason + "\r\n";
	$template += "--------------------------Steps to Resolve----------------------------\r\n\r\n" + $steps + "\r\n";

	if($("#vmcMyChart").prop('checked')) $template += "Verified: ";
	else $template += ""
	if($("#verName").prop('checked'))
	{
		if($("#vmcMyChart").prop('checked'))
		{
			$template += "Name  ";
		}
	}
	else $template += ""
	if($("#verDOB").prop('checked'))
	{
		if($("#vmcMyChart").prop('checked'))
		{
			$template += "DOB  ";
		}
	}
	else $template += ""
	if($("#verSSN").prop('checked'))
	{
		if($("#vmcMyChart").prop('checked'))
		{
			$template += "SSN  ";
		}
	}
	else $template += ""
	if($("#verAddress").prop('checked'))
	{
		if($("#vmcMyChart").prop('checked'))
		{
			$template += "Address  ";
		}
	}
	else $template += ""
	if($("#verMember").prop('checked'))
	{
		if($("#vmcMyChart").prop('checked'))
		{
			$template += "Member # \r\n";
		}
	}
	else $template += " \r\n";

	if ($("#vmcPatientBox").prop('checked'))
	{
		if ($mrn != "") $phi += "MRN/FIN: " + $mrn + " \r\n";
		else $infoMissing += "MRN/FIN is required!";
	}

	if ($("#vmcTechPHI").prop('checked'))
	{
		if ($techPatName != "") $phi += "Name: " + $techPatName + " \r\n";
		if ($techMRN != "") $phi += "MRN/FIN: " + $techMRN + " \r\n";
		else $infoMissing += "MRN/FIN is required!";
		if ($techDOB != "") $phi += "DOB: " + $techDOB + " \r\n";
		if ($techSSN != "") $phi += "SSN: " + $techSSN + " \r\n";
		if ($techApp != "") $phi += "Application #: " + $techApp + " \r\n";
	}

	if ($("input[name=vmcTicketType]:checked").val() == "2")
	{
		$template += "--------------------------Required Questions:-------------------------\r\n";
		if ($vmcAffecting != "") $template += "Who is this affecting? " + $vmcAffecting + " \r\n";
		else $infoMissing += "Who is this affecting? field required! ";
		if ($vmcStart != "") $template += "When did this start? "  + $vmcStart + " \r\n";
		else $infoMissing += "When did this start? field required! ";
		if ($vmcBefore != "") $template += "Did this work before? " + $vmcBefore + " \r\n";
		else $infoMissing += "Did this work before? field required! ";
		if ($vmcChanged != "") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		else $infoMissing += "Has anything changed since it last worked? field required! ";
		if ($vmcError != "") $template += "List any error messages: " +  $vmcError + " \r\n";
		else $infoMissing += "List any error messages: field required! ";

	}

	if ($("#phiBox").prop('checked'))
	{
		if ($mrn != "") $phi += "MRN : " + $mrn + " \r\n";
		if ($dob != "") $phi += "DOB : " + $dob + " \r\n";
		if ($caseID != "") $phi += "Case ID : " + $caseID + " \r\n";
		if ($UMID != "") $phi += "UM ID : " + $UMID + " \r\n"

	}

	if ($infoMissing != "") alert($infoMissing);

	$("#vmcPhiBox").val($phi);
	$("#vmcTemplate").val($template);
	$("#vmcTemplate").select();
}

function Presbyterian()
{
	var infoMissing = false;
	var $phoneNum = $("#presbyterianPhoneNum").val();
	var $altPhone = $("#presbyterianAltNum").val();
	var $userID = $("#presbyterianUserID").val();
	var $role = $("#presbyterianRole").val();
	var $location = $("#presbyterianLocation").val();
	var $pcid = $("#presbyterianPCID").val();
	var $reason = $("#presbyterianReason").val();
	var $steps = $("#presbyterianSteps").val();
	var $affected = $("#presbyterianAffected").val();
	var $start = $("#presbyterianStart").val();
	var $worked = $("#presbyterianWorked").val();
	var $changed = $("#presbyterianChanged").val();
	var $errorMessage = $("#presbyterianErrorMessage").val();
	var $phpCitrix = $("#presbyterianPHPCitrix").val();
	var $careManager = $("#presbyterianCareManager").val();
	var	$kb = $("#presbyterianKb").val();
	var	$mrn = $("#mrn").val();
	var	$dob = $("#dob").val();
	var	$caseID = $("#caseID").val();
	var	$UMID = $("#UMID").val();
	var $phi = "";

	var $template = "--------------------------User Information------------------------\r\n";
	$template += "Phone Number: " + $phoneNum + "\r\n";
	if ($altPhone !="") $template += "Alt. Phone Number: " + $altPhone + "\r\n"
	else $template += "Alt. Phone Number: No Alternate Phone Number \r\n";
	$template += "User ID: " + $userID + "\r\n";
	$template += "Current Location: " + $location + "\r\n\r\n";
	if ($pcid != "" )
	{
		$template += "PCID: " + $pcid + "\r\n";
	}else
	{
		$template += "PCID: Not needed\r\n";
	}
	$template += "--------------------------Reason for Call-------------------------\r\n\r\n" + $reason + "\r\n\r\n";

	if ($kb !="") $template += "KB:" +  $kb + " \r\n";
	$template += "--------------------------Steps to Resolve------------------------\r\n\r\n" + $steps + "\r\n\r\n";


	// Incident and Printer templates require these basic field
	if ($("input[name*=presbyterianTicketType]:checked").val() == "2" || $("input[name*=presbyterianTicketType]:checked").val() == "3")
	{
		$template += "--------------------------Required Questions:---------------------\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + "\r\n";

	}

	// additional  info for Printer
	if ($("input[name*=presbyterianTicketType]:checked").val() == "3" )
	{
		$template += "--------------------------Required Questions:---------------------\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + "\r\n";

	}

	// addl info for Care Manger
	if ($("input[name*=presbyterianTicketType]:checked").val() == "4" )
	{
		$template += "--------------------------Required Questions:---------------------\r\n";
		if ($phpCitrix !="")  $template += "Is the user able to log into the PHP Citrix?" + $phpCitrix + " \r\n";
		if ($careManager !="")  $template += "Is the user able to log into the PHP Citrix?" + $careManager + " \r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + "\r\n";

	}
	if ($("input[name*=presbyterianTicketType]:checked").val() == "5" )
	{
		$template += "--------------------------Required Questions:---------------------\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($worked !="") $template += "Did this work before? " + $worked + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + "\r\n";

	}

	if ($("#phiBox").prop('checked'))
	{
		if ($mrn != "") $phi += "MRN : " + $mrn + " \r\n";
		if ($dob != "") $phi += "DOB : " + $dob + " \r\n";
		if ($caseID != "") $phi += "Case ID : " + $caseID + " \r\n";
		if ($UMID != "") $phi += "UM ID : " + $UMID + " \r\n"

	}


	$("#phiInfo").val($phi);
	$("#presbyterianTemplate").val($template);
	$("#presbyterianTemplate").select();
}

function Aerojet()
{
	var infoMissing = false;
	var $template ="";
	var $user = $("#AerojetUser").val();
	var $badge = $("#AerojetBadge").val();
	var $verification = $("#AerojetVerification").val();
	var $location = $("#AerojetLocation").val();
	var $contact = $("#AerojetPhone").val();
	var $pcid = $("#AerojetPCID").val();
	var $application = $("#AerojetApplication").val();
	var $kb = $("#AerojetKB").val();
	var $issue = $("#AerojetReason").val();
	var $resolved = $("#AerojetResolved").val();
	var $troubleshooting = $("#AerojetTroubleshooting").val();
	var $infoMissing = "";
	var $itemsVerified = 0;

	$template += "---------User---------\r\n";
	if ($user != "")
	{
		$template += "User: " + $user + "\r\n";
		$itemsVerified ++;
	}
	if ($badge != "")
	{
		$template += "Badge: " + $badge + "\r\n";
		$itemsVerified ++;
	}
	if ($verification != "")
	{
		$template += "Other Verification: " + $verification + "\r\n";
		$itemsVerified ++;
	}

	if ($itemsVerified < 3)
	{
		$infoMissing = "All of the Verification items are required!";
	}

	if ($location !="") $template += "Location: " + $location + "\r\n";
	if ($contact !="") $template += "Best Contact Number: " + $contact + "\r\n";
	if ($pcid !="") $template += "PCID: " + $pcid + "\r\n";
	if ($application !="") $template += "Application: " + $application + "\r\n";
	$template += "\r\n";
	$template += "-----------Issue----------\r\n" + $issue +"\r\n\r\n";
	$template += "----Troubleshooting Note---\r\n" + $troubleshooting +"\r\n\r\n";
	$template += "---------Resolution----------\r\n" + $resolved+"\r\n\r\n";


	if ($infoMissing == "")
	{
		$("#AerojetTemplate").val($template);
		$("#AerojetTemplate").select();
	}else
	{
		$("#AerojetTemplate").val("");
		alert($infoMissing);
	}


}


function CodeC()
{
	var $caller = $("#caller").val();
	var $itTeam = $("#itTeam").val();
	var $codeCApplication = $("#codeCApplication").val();
	var $type = $("#type").val();
	var $ticket = $("#ticket").val();
	var $codeCFacilities = $("#codeCFacilities").val();
	var $etr = $("#etr").val();
	var $details = $("#details").val();
	var $banner = false;
	var $timePaged = $("#time").val();
	var $newLine = escape("\n");
	var $tabChar = "%09";
	var $codeCEmail = "mailto:ABQ_GBS_Technical_All@UnityBPO.com; ABQ_GBS_Clinical_All@UnityBPO.com; ABQ_GBS_Leadership@UnityBPO.com; ABQ_GBS_Management@UnityBPO.com; ABQ_GBS_AHS_All@UnityBPO.com?cc=itfieldservices@integrisok.com&subject=Code C&body=" +$tabChar + $tabChar +"Code C" + $newLine + $newLine;

	if ($("#type-0").prop('checked')) $planned = "UNPLANNED";
	if ($("#type-1").prop('checked')) $planned = "PLANNED";

	if ($("#banner-0").prop('checked')) $banner = "Yes";
	if ($("#banner-1").prop('checked')) $banner = "No";


	var $text = "Code C / " + $("#codeCApplication").val() + " / " + $codeCFacilities + " FACILITIES / " + $planned;

	$("#formCaller").text($caller);
	$("#team").text($itTeam);
	$("#codeCApplicationImpacted").text($codeCApplication);
	$("#planned").text($planned);
	$("#ticketNum").text($ticket);
	$("#impactedFacilities").text($codeCFacilities);
	$("#etrGiven").text($etr );
	$("#addDetails").text($details);
	$("#timePaged").text($timePaged);
	$("#bannerUp").text($banner);
	$text += " / " + $("#ticket").val();
	$("#CodeCTemplate").val($text.toUpperCase());
	$("#CodeCTemplate").select();

	$codeCEmail += "Caller:" + $tabChar + $tabChar + $tabChar + $tabChar + $tabChar + $caller + $newLine;
	$codeCEmail += "IT Team Calling:\t" + $tabChar + $tabChar + $tabChar + $tabChar + $itTeam + $newLine;
	$codeCEmail += "Application or System Impacted:\t" + $tabChar + $codeCApplication + $newLine;
	$codeCEmail += "Planned/Unplanned:\t" + $tabChar + $tabChar + $tabChar + $planned + $newLine;
	$codeCEmail += "Ticket#:\t\t" + $tabChar + $tabChar + $tabChar + $tabChar + $ticket + $newLine;
	$codeCEmail += "Facilities impacted:\t\t" + $tabChar + $tabChar + $tabChar + $codeCFacilities + $newLine;
	$codeCEmail += "ETR Given:\t\t" + $tabChar + $tabChar + $tabChar + $tabChar + $etr +$newLine;
	$codeCEmail += "Additional Details (if available):\t\t" + $tabChar + $tabChar + $details + $newLine;
	$codeCEmail += "Time Paged:\t\t" + $tabChar + $tabChar + $tabChar + $tabChar + $planned + $newLine;
	$codeCEmail += "Banner:\t\t" + $tabChar + $tabChar + $tabChar + $tabChar + $banner + $newLine;
	$("#codeCEmail").removeClass("disabled");
	$("#codeCEmail").attr('href', $codeCEmail);

}


function Honeywell()
{
	var $template ="";
	var $ticketID = $("#HoneywellTicketID").val();
	var $reason = $("#HoneywellReason").val();
	var $error = $("#HoneywellError").val();
	var $resolved = $("#HoneywellResolved").val();
	var $verified = $("#HoneywellVerified").prop("checked");
	var $source = $("#HoneywellSource").val();
	var $troubleshooting = $("#HoneywellTroubleshooting").val();
	var $kbUsed = $("#HoneywellKBUsed").prop("checked");
	var $phone = $("#HoneywellPhone").val();
	var $user = $("#HoneywellName").val();
	var $infoMissing = "";

	$template += "---------User---------\r\n";
	if ($verified)
	{
		$template += "User Verified\r\n";
	}else
	{
		if ($user != "") $template += "User: "  + $user + "\r\n"
		else $infoMissing += "User required ";
		if ($phone != "") $template += "Phone: " + $phone + "\r\n";
	}
	$template += "\r\n";
	$template += "-----Reason For Contact----\r\n" + $reason +"\r\n\r\n";
	$template += "-----Error Encountered-----\r\n" + $error +"\r\n\r\n";
	$template += "----Troubleshooting Note---\r\n" + $troubleshooting +"\r\n\r\n";
	$template += "---------Resolution----------\r\n" + $resolved + "\r\n";
	if ($reason == "") $infoMissing += "Reason Required ";
	if ($resolved == "") $infoMissing += "Resolution required Required ";

	if ($("#HoneywellKB-1").prop("checked"))
	{
		if ($source != "") $template += "Source used to troubleshoot: " + $source +"\r\n"
		else $infoMissing += "Source required "
	}else
	{
		$template += "Kb exsists, KB ";
		if (!$kbUsed) $template += "not ";
		$template += "utilized \r\n"
	}
	if ($infoMissing == "")
	{
		$("#HoneywellTemplate").val($template);
		$("#HoneywellTemplate").select();
	}else
	{
		$("#HoneywellTemplate").val("");
		alert($infoMissing);
	}


}

function phiCopy()
{
	$("#phiInfo").select();
	document.execCommand("copy");
}

function epicPhiCopy()
{
	$("#epicPhiBox").select();
	document.execCommand("copy");
}
function passwordReset()
{
	var $kbArray = ["KB0001011", "KB0000827", "KB0002380", "KB0006871", "KB0000896", "KB0000929", "KB0001114", "KB0006380" ];

	if ( $("#application").val() != "")
	{
		var $appID = $("#application").val()
		var $app = $("#application option[value='"+$appID+"']").text();
		var $steps = "";
		$("#issue").val($app + " Password Reset \r\n");
		if ($("#ssnVerified").prop('checked')) $steps += "Verified SSN \r\n";
		$steps += $app +" Password Reset Per " + $kbArray[$appID] + "\r\nUser Verified resolution ";
		$("#steps").val($steps);
	}else
	{
		$("#issue").val("");
		$("#steps").val("");
	}
	$("#application").val("");
	$("#ssnVerified").prop('checked', false);


}

function AmedT()
{
	var $infoMissing = false;
	var $template = "";
	var $contract = $(".contract.active").html();
	var $userName = $("#amedisysUserName").val();
	var $phoneNum = $("#amedisysPhoneNum").val();
	var $altPhone = $("#epicAltNum").val();
	var $userID = $("#amedisysUserID").val();
	var $role = $("#amedisysRole").val();
	var $location = $("#amedisysLocation").val();
	var $computer = $("#amedisysComputerName").val();
	var $asset = $("#amedisysAsset").val();
	var $location = $("#amedisysLocation").val();
	var $issue = $("#AmedisysReason").val();
	var $steps = $("#AmedisysTroubleshooting").val();
	var $affected = $("#AmedisysAffected").val();
	var $start = $("#AmedisysStart").val();
	var $changed = $("#AmedisysChanged").val();
	var $errorMessage = $("#AmedisysErrorMessage").val();
	var $kb = $("#AmedisysKBUsed").val();
	var $worked = $("#AmedisysChanged").val();
	var $acaTOD = $("#amedAppAcaTOD").val();
	var $acaDOS = $("#amedAppAcaDOS").val();
	var $acaBrow = $("#amedAppAcaBrow").val();
	var $acaCName = $("#amedAppAcaCourseName").val();
	var $acaCNumber = $("#amedAppAcaCourseNumber").val();

	$template += $("#AmedisysSummary").val() + "\r\n"
	$template += "----------User Information------------\r\n";
	if ($location != "") $template += "4 digit location: "  + $location + "\r\n";
	if ($phoneNum != "") $template += "Call back #: "  + $phoneNum + "\r\n";
//	if ($userName != "") $template += "User: "  + $userName + "\r\n";
	if ($userName != "") $template += "User ID: "  + $userName + "\r\n";
	if ($role != "") $template += "Role: "  + $role + "\r\n";
	if($("#amedtNHY").prop('checked')) $template += "End user is a new hire: Yes" + "\r\n";
	else $template += "End user is a new hire: No" + "\r\n"
	if ($("#AmedisysApplication").val() == "13")
		{
			$template += "Type of device: " + $acaTOD + "\r\n";
			$template += "Device OS: " + $acaDOS + "\r\n";
			if($("#amedAcaOff").prop('checked')) $template += "Location: Office / Care Center" + "\r\n";
			if($("#amedAcaRem").prop('checked')) $template += "Location: Remote" + "\r\n";
			$template += "Browser Type and Version: " + $acaBrow + "\r\n";
			$template += "Course Name: " + $acaCName + "\r\n";
			$template += "Course Number: " + $acaCNumber + "\r\n";
			if($("#amedAcaYes").prop('checked')) $template += "Tried steps from guides: Yes" + "\r\n";
			if($("#amedAcaNo").prop('checked')) $template += "Tried steps from guides: No" + "\r\n";
		}

	if ($computer != "") $template += "Computer Name: "  + $computer + "\r\n";
	if ($asset != "") $template += "Asset Tag: "  + $asset + "\r\n";
//	if ($user != "") $template += "User: "  + $user + "\r\n";
	$template += "\r\n----------Reason for Call------------\r\n" + $issue + "\r\n";
	$template += "\r\n---------Steps to Resolve-----------\r\n";
	if ($("#amedisysVerified").prop('checked')) $template += "User Verified: Yes \r\n";
	else $template += "User Verified: N/A \r\n"
	$template += $steps + "\r\n";

	if ($("input[name=AmedisysTicketType]:checked").val() == "2")
	{
		$template += "-------------Incident Questions-----------\r\n";
		if ($affected !="") $template += "Who is this affecting? " + $affected + " \r\n";
		if ($start != "") $template += "When did this start? "  + $start + " \r\n";
		if ($changed !="") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
		if ($errorMessage !="") $template += "List any error messages: " +  $errorMessage + " \r\n";
		if ($kb !="") $template += "KB:" +  $kb + " \r\n";

	}
	$("#AmedisysTemplate").val($template);
	$("#AmedisysTemplate").select();


}

function AmedisysSummary()
{
	var $application = "";
	var $location = $("#amedisysLocation").val();
	$location = $location.substr(0,4);
	if ($("#hchb").prop("checked")) var $deviceType = "HCHB";
	else var $deviceType = "PC";
	if ( $("#AmedisysApplication").val() != "" && $("#AmedisysApplication").val() != "3")
	{
		$application = $amedisysApps[$("#AmedisysApplication").val()].application;
	}else if ($("#AmedisysApplication").val() == "3" && $("#AmedisysApplication").val() != "")
	{
		$application = $("#amedisysApplicationOther").val()
	}
	var $issue = $("#AmedisysSummaryIssue").val();
	if (jQuery.inArray($location, $infinity) >= 0)  $("#AmedisysSummary").val( "[INF] " + $application + " - " + $issue)
	else $("#AmedisysSummary").val( $application + " - " + $issue);

}

function amedisysApplication()
{
	$(".amedisysApplicationOther").addClass("hidden");
	$(".amedisysApplicationAcademy").addClass("hidden");
	if ( $("#AmedisysApplication").val() != "" && $("#AmedisysApplication").val() != "3" && $("#AmedisysApplication").val() != "13")
	{
		AmedisysSummary();
	}else
	{
		if ($("#AmedisysApplication").val() == "3") $(".amedisysApplicationOther").removeClass("hidden");
		if ($("#AmedisysApplication").val() == "13") $(".amedisysApplicationAcademy").removeClass("hidden");
	}
}


//{
//	$(".amedisysApplicationAcademy").addClass("hidden");
//	if ( $("#AmedisysApplication").val() != "" && $("#AmedisysApplication").val() != "13")
//	{
//		AmedisysSummary();
//	}else
//	{
//		if ($("#AmedisysApplication").val() == "13") $(".amedisysApplicationAcademy").removeClass("hidden");
//	}
//}

function AmedisysReset()
{
	if ($("#amedisysVerified").prop('checked')) $("#amedisysVerified").click();
	if ($("#Hospice").prop("checked")) $("#HomeCare").click();

	$("#AmedisysApplication").val("");
}


function AmedC()
{
	var $infoMissing = false;
	var $contract = $(".contract.active").html();
	var $name = $("#amedcName").val();
	var $userID = $("#amedcUID").val();
	var $application = $("#amedcApp").val();
	var $location = $("#amedcLocation").val();
	var $phone = $("#amedcPhone").val();
	var $role = $("#amedcRole").val();
	var $comName = $("#amedcComName").val();
	var $asset = $("#amedcAsset").val();
	var $patName = $("#amedcPatName").val();
	var $visit = $("#amedcVisit").val();
	var $order = $("#amedcOrder").val();
	var $mrn = $("#amedcMRN").val();
	var $event = $("#amedcEvent").val();
	var $soe = $("#amedcSOE").val();
	var $reason = $("#amedcReason").val();
	var $steps = $("#amedcTSteps").val();
	var $affected = $("#amedcAffected").val();
	var $start = $("#amedcStart").val();
	var $work = $("#amedcWork").val();
	var $changed = $("#amedcChanged").val();
	var $error = $("#amedcError").val();
	var $knowledge = $("#amedcKBA").val();

	$template = $("#amedcSummary").val() + "\r\n";
	$template += "--------------------------User Information----------------------------\r\n";
	$template += "Name: " + $name + "\r\n";
	$template += "User ID: " + $userID + "\r\n";
	$template += "Location: " + $location + "\r\n";
	if($("#amedcNHY").prop('checked')) $template += "End user is a new hire: Yes" + "\r\n";
	else $template += "End user is a new hire: No" + "\r\n"
	$template += "Phone Number: " + $phone + "\r\n";
	$template += "Job Title / Role: " + $role + "\r\n";
	if($("#amedcNA").prop('checked')) $template += "Backoffice / PointCare: N/A" + "\r\n";
	if($("#amedcBO").prop('checked')) $template += "Backoffice / PointCare: Backoffice" + "\r\n";
	if($("#amedcPC").prop('checked')) $template += "Backoffice / PointCare: PointCare" + "\r\n";
	if($("#amedcVerified").prop('checked')) $template += "User Verified: Yes \r\n";
	else $template += "User Verified: No \r\n"
	$template += "Computer Name: " + $comName + "\r\n";
	$template += "Asset Tag: " + $asset + "\r\n";
	$template += "--------------------------Reason for Call----------------------------\r\n";
	$template += $reason + "\r\n";
	$template += "--------------------------Steps to Resolve---------------------------\r\n";
	$template += $steps + "\r\n";

	$("#amedcTemplate").val($template);
	$("#amedcTemplate").select();
}

function amedcSummary()
{
	var $application = "";
	if ($("#amedcHH").prop("checked")) var $hch = "HH";
	if ($("#amedcHSP").prop("checked")) var $hch = "HSP";
	if ($("#amedcCorp").prop("checked")) var $hch = "Corp";
	var $location = $("#amedcLocation").val();
	if ($("#amedcApp").val() != "" && $("#amedcApp").val() != "3")
	{
		$application = $amedcApps[$("#amedcApp").val()].application;
	}else if ($("#amedcApp").val() == "3" && $("#amedcApp").val() != "")
	{
		$application = $("#amedcAppOther").val()
	}
	var $issue = $("#amedcSummaryIssue").val();
	$("#amedcSummary").val( $hch + " - " + $location + " - "  + $application + " - " + $issue);
}

function amedcApplication()
{
	$(".amedcAppOther").addClass("hidden");
	if ( $("#amedcApp").val() != "" && $("#amedcApp").val() != "3")
	{
		AmedisysSummary();
	}else
	{
		if ($("#amedcApp").val() == "3") $(".amedcAppOther").removeClass("hidden");
	}
}


function Visiting()
{
	var $infoMissing = false;
	var $contract = $(".contract.active").html();
	var $userName = $("#vnsnyName").val();
	var $userID = $("#vnsnyUID").val();
	var $location = $("#vnsnyLocation").val();
	var $phone = $("#vnsnyPhone").val();
	var $role = $("#vnsnyRole").val();
	var $application = $("#vnsnyApps").val();
	var $issueSummary = $("#vnsnyIssueSummary").val();
	var $computerName = $("#vnsnyAssetName").val();
	var $assetTag = $("#vnsnyAssetTag").val();
	var $reason = $("#vnsnyReason").val();
	var $steps = $("#vnsnySteps").val();
	var $prefPhone = $("#vnsnyPrefPhone").val();
	var $prefTime = $("#vnsnyPrefTime").val();
	var $prefEmail = $("#vnsnyPrefEmail").val();
	var $patName = $("input[name=vnsnyPatientName][class*="+ $contract +"]").val();
	var $visitType = $("input[name=vnsnyVisitType][class*="+ $contract +"]").val();
	var $orderNum = $("input[name=vnsnyOrder][class*="+ $contract +"]").val();
	var $mrn = $("input[name=vnsnyMRN][class*="+ $contract +"]").val();
	var $visitDate = $("input[name=vnsnyVisitDate][class*="+ $contract +"]").val();
	var $episode = $("input[name=vnsnyEpisode][class*="+ $contract +"]").val();
	var $phi="";

	if ($("#vnsnyHH").prop('checked'))
		{
			$template = "CHHA" + " - " + $location + " - " + $application + " - " + $issueSummary + "\r\n";
	}

	if ($("#vnsnyHSP").prop('checked'))
		{
			$template = "HSP" + " - " + $location + " - " + $application + " - " + $issueSummary + "\r\n";
	}

	$template += "User Name: " + $userName + "\r\n";
	$template += "User ID: " + $userID + "\r\n";
	$template += "Location: " + $location + "\r\n";
	if ($("#vnsnyHH").prop('checked')) $template += "HH or HSP: Home Health \r\n";
	else $template += ""
	if ($("#vnsnyHSP").prop('checked')) $template += "HH or HSP: Hospice \r\n";
	else $template += ""
	if ($("#prefPhone").prop('checked'))
		{
			$template += "Preferred contact type: Phone" + "\r\n";
			$template += "Phone number: " + $prefPhone + "\r\n";
			$template += "Preferred contact time: " + $prefTime + "\r\n";
		}
	if ($("#prefEmail").prop('checked'))
	{
		$template += "Preferred contact type: Email" + "\r\n";
		$template += "Email address: " + $prefEmail + "\r\n";
	}
	$template += "Role: " + $role + "\r\n";
	if ($("#vnsnyBO").prop('checked')) $template += "Backoffice or Pointcare: Backoffice \r\n";
	else $template += ""
	if ($("#vnsnyPO").prop('checked')) $template += "Backoffice or Pointcare: Pointcare \r\n";
	else $template += ""
	if ($("#vnsnyNA").prop('checked')) $template += "";
	else $template += ""
	$template += "Application: " + $application + "\r\n";
	$template += "Asset Name: " + $computerName + "\r\n";
	$template += "Asset Tag #: " + $assetTag + "\r\n";
	if ($("#vnsnyVerified").prop('checked')) $template += "User Verified: Yes \r\n";
	else $template += "User Verified: No \r\n"
	$template += "--------------------------Reason for Call-----------------------------\r\n\r\n" + $reason + "\r\n";
	$template += "--------------------------Steps to Resolve---------------------------\r\n\r\n" + $steps + "\r\n";


	if ($("#vnsnyPatientBox").prop('checked'))
	{
		if ($patName != "") $template += "Patient Name: " + $patName + " \r\n";
		if ($visitType != "") $template += "Visit Type/Code: " + $visitType + " \r\n";
		if ($orderNum != "") $template += "MD Order #: " + $orderNum + " \r\n";
		if ($mrn != "") $template += "MRN: " + $mrn + " \r\n";
		if ($visitDate != "") $template += "Date of Visit/Event: " + $visitDate + " \r\n";
		if ($episode != "") $template += "Start of Episode: " + $episode + " \r\n";

	}

	if ($("#vnsnyPatientBox").prop('checked'))
	{
		if ($patName != "") $phi += "Patient Name: " + $patName + " \r\n";
		if ($visitType != "") $phi += "Visit Type/Code: " + $visitType + " \r\n";
		if ($orderNum != "") $phi += "MD Order #: " + $orderNum + " \r\n";
		if ($mrn != "") $phi += "MRN: " + $mrn + " \r\n";
		if ($visitDate != "") $phi += "Date of Visit/Event: " + $visitDate + " \r\n";
		if ($episode != "") $phi += "Start of Episode: " + $episode + " \r\n";

	}

	$("#vnsnyPhiBox").val($phi);
	$("#vnsnyTemplate").val($template);
	$("#vnsnyTemplate").select();
}

function Graham()
{
	var $infoMissing = false;
	var $contract = $(".contract.active").html();
	var $userName = $("#ghgName").val();
	var $userID = $("#ghgUID").val();
	var $callbackNum = $("#ghgCallback").val();
	var $location = $("#ghgLocation").val();
	var $phone = $("#ghgPhone").val();
	var $role = $("#ghgRole").val();
	var $application = $("#ghgApps").val();
	var $issueSummary = $("#ghgIssueSummary").val();
	var $computerName = $("#ghgAssetName").val();
	var $assetTag = $("#ghgAssetTag").val();
	var $reason = $("#ghgReason").val();
	var $steps = $("#ghgSteps").val();
	var $patName = $("input[name=ghgPatientName][class*="+ $contract +"]").val();
	var $visitType = $("input[name=ghgVisitType][class*="+ $contract +"]").val();
	var $orderNum = $("input[name=ghgOrder][class*="+ $contract +"]").val();
	var $mrn = $("input[name=ghgMRN][class*="+ $contract +"]").val();
	var $visitDate = $("input[name=ghgVisitDate][class*="+ $contract +"]").val();
	var $episode = $("input[name=ghgEpisode][class*="+ $contract +"]").val();
	var $phi="";
{
	$template = "User Name: " + $userName + "\r\n";
	$template += "User ID: " + $userID + "\r\n";
	$template += "Callback #: " + $callbackNum + "\r\n";
	$template += "Location: " + $location + "\r\n";
	$template += "Role: " + $role + "\r\n";
	$template += "Application: " + $application + "\r\n";
	$template += "Asset Name: " + $computerName + "\r\n";
	$template += "Asset Tag #: " + $assetTag + "\r\n";
	if ($("#ghgVerified").prop('checked')) $template += "User Verified: Yes \r\n";
	else $template += "User Verified: No \r\n"
	$template += "--------------------------Reason for Call-----------------------------\r\n\r\n" + $reason + "\r\n";
	$template += "--------------------------Steps to Resolve---------------------------\r\n\r\n" + $steps + "\r\n";
}

	if ($("#PatientBox").prop('checked'))
	{
		if ($patName != "") $template += "Patient Name: " + $patName + " \r\n";
		if ($visitType != "") $template += "Visit Type/Code: " + $visitType + " \r\n";
		if ($orderNum != "") $template += "MD Order #: " + $orderNum + " \r\n";
		if ($mrn != "") $template += "MRN: " + $mrn + " \r\n";
		if ($visitDate != "") $template += "Date of Visit/Event: " + $visitDate + " \r\n";
		if ($episode != "") $template += "Start of Episode: " + $episode + " \r\n";

	}

	if ($("#ghgPatientBox").prop('checked'))
	{
		if ($patName != "") $phi += "Patient Name: " + $patName + " \r\n";
		if ($visitType != "") $phi += "Visit Type/Code: " + $visitType + " \r\n";
		if ($orderNum != "") $phi += "MD Order #: " + $orderNum + " \r\n";
		if ($mrn != "") $phi += "MRN: " + $mrn + " \r\n";
		if ($visitDate != "") $phi += "Date of Visit/Event: " + $visitDate + " \r\n";
		if ($episode != "") $phi += "Start of Episode: " + $episode + " \r\n";

	}

	$("#ghgPhiBox").val($phi);
	$("#ghgTemplate").val($template);
	$("#ghgTemplate").select();
}

function Mobility()
{
	var $infoMissing = "";
	var $contract = $(".contract.active").html();
	var $userName = $("#mobName").val();
	var $userID = $("#mobUserID").val();
	var $location = $("#mobLocation").val();
	var $phone = $("#mobCallback").val();
	var $role = $("#mobRole").val();
	var $reason = $("#mobReason").val();
	var $steps = $("#mobSteps").val();
	var $verfieid = $("#mobVerified").val();
	var $imei = $("#mobIMEI").val();
	var $iccid = $("#mobICCID").val();
	var $setup = $("#mobTime").val();
	var $analyst = $("#mobAnalyst").val();
	var $contractor = $("#mobContract").val();
	var $qpm = $("#mobQPM").val();
	var $nal = $("#mobNAL").val();
	var $hchb = $("#mobHCHB").val();
	var $maas = $("#mobMaas").val();
	var $maasNum = $("#mobMaasNum").val();
	var $address = $("#mobReturn").val();
	var $service = $("#mobService").val();
	var $config = $("#mobConfig").val();
	var $tabType = $("#mobTabType").val();
	var $battery = $("#mobBattery").val();
	var $fdr = $("#mobFDR").val();
	var $reasons = $("#mobReason").val();
	var $steps = $("#mobSteps").val();
		{
			$template = $("#mobSumLine").val() + "\r\n";
			$template += "--------------------------User Information----------------------------\r\n";
			$template += "User Name: " + $userName + "\r\n";
			$template += "User ID: " + $userID + "\r\n";
			$template += "Callback #: " + $phone + "\r\n";
			$template += "Location: " + $location + "\r\n";
			$template += "Role/Job Title: " + $role + "\r\n";
		}
			$template += "--------------------------Reason for Call----------------------------\r\n" + "User requires a tablet setup for: " + "\r\n";
			$template += $reasons + "\r\n";
			$template += "--------------------------Steps to Resolve---------------------------\r\n";
			if($("#mobVerYes").prop('checked')) $template += "User Verified: Yes" + "\r\n";
			if($("#mobVerNo").prop('checked')) $template += "User Verified: No" + "\r\n";
			$template += "IMEI: " + $imei + "\r\n";
			$template += "ICCID: " + $iccid + "\r\n";
			if($("#mobICCID").val().match(/8914.*/)) $template += "Service Provider: Verizon" + "\r\n";
			{
				if($("#mobICCID").val().match(/8914.*/)) $infoMissing += "This is a Verizon device! Ensure your notes reflect that!";
			}
			if($("#mobICCID").val().match(/89014.*/)) $template += "Service Provider: AT&T" + "\r\n";
			{
				if($("#mobICCID").val().match(/89014.*/)) $infoMissing += "This is a AT&T device! Ensure your notes reflect that!";
			}
			if ($("#mobEST").prop('checked')) $template += "Customer Time Zone: Eastern Time \r\n";
			else $template += ""
			if ($("#mobCST").prop('checked')) $template += "Customer Time Zone: Central Time \r\n";
			else $template += ""
			if ($("#mobMST").prop('checked')) $template += "Customer Time Zone: Mountain Time \r\n";
			else $template += ""
			if ($("#mobPST").prop('checked')) $template += "Customer Time Zone: Pacific Time \r\n";
			else $template += ""
			$template += "Date/Time of Setup: " + $setup + "\r\n";
			$template += "Analyst: " + $analyst + "\r\n";
			$template += $steps + "\r\n";
			$template += "--------------------------Required Questions-------------------------\r\n";
			if($("#mobConYes").prop('checked')) $template += "Is this a Contractor? Yes" + "\r\n";
			if($("#mobConNo").prop('checked')) $template += "Is this a Contractor? No" + "\r\n";
			if($("#mobNALYes").prop('checked')) $template += "Account showing active in NAL? Yes" + "\r\n";
			if($("#mobNALNo").prop('checked')) $template += "Account showing active in NAL? No" + "\r\n";
			if($("#mobHCHBYes").prop('checked')) $template += "Account showing active in HCHB? Yes" + "\r\n";
			if($("#mobHCHBNo").prop('checked')) $template += "Account showing active in HCHB? No" + "\r\n";
			if($("#mobMaasYes").prop('checked')) $template += "Account showing active in MaaS360? Yes" + "\r\n";
			if($("#mobMaasNo").prop('checked')) $template += "Account showing active in MaaS360? No" + "\r\n";
			$template += "Number of MaaS360 Device Records: " + $maasNum + "\r\n";
			if($("#mobRetYes").prop('checked')) $template += "Device Return Address Provided? Yes" + "\r\n";
			if($("#mobRetNo").prop('checked')) $template += "Device Return Address Provided? No" + "\r\n";
			if($("#mobSerYes").prop('checked')) $template += "Verified Device has service? Yes" + "\r\n";
			if($("#mobSerNo").prop('checked')) $template += "Verified Device has service? No" + "\r\n";
			if($("#mobConfigYes").prop('checked')) $template += "Configuration Item filled with Device ID? Yes" + "\r\n";
			if($("#mobConfigNo").prop('checked')) $template += "Configuration Item filled with Device ID? No" + "\r\n";
			if($("#mobTabE").prop('checked')) $template += "Device is a: Samsung Tab E" + "\r\n";
			if($("#mobTab4").prop('checked')) $template += "Device is a: Samsung Tab 4" + "\r\n";
			if($("#mobTabE").prop('checked'))
			{
				if($("#mobBatYes").prop('checked')) $template += "Tab E device is at/above 80%" + "\r\n";
				if($("#mobBatNo").prop('checked')) $template += "Tab E device is below 80%" + "\r\n";
			}
			if($("#mobFDRYes").prop('checked')) $template += "An FDR/Wipe has been performed on this device." + "\r\n";
			if($("#mobFDRNo").prop('checked')) $template += "An FDR/Wipe has not been performed on this device." + "\r\n";

	if ($infoMissing != "") alert($infoMissing);

	$("#mobTemplate").val($template);
	$("#mobTemplate").select();
}

function mobilitySummary()
{
	if ($("#mobDeptHH").prop("checked")) var $hct = "HH";
	else var $hct = "HSP";
	var $location = $("#mobLocation").val();
	var $mobSum = $("#mobSum").val();
	if ($("#mobTagFTS").prop("checked")) var $tag = "[FTS]";
	else var $tag = "[AEU]";
	$("#mobSumLine").val($hct + " - "  + $location + " - " + $mobSum + " - " + $tag);
}
