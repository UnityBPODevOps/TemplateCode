// Dynamic Data for templates



// format for Pres application data [Application id, Name, reson for call text", "steps to resolve" ] \n define new line
var $presApps = [
		{
			appID: 0,
			application: "Epic",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 1,
			application: "Outlook",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 2,
			application: "Citrix",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 3,
			application: "Other",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 4,
			application: "Windows",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 5,
			application: "CareManager",
			callReason:"User is a Care Coordinator and is with Paula Casey",
			resolutionSteps:"- Remoted in\n- Doc ID:405879\n- Added to the trusted sites\n- Added to the sites in the Per Site Privacy Actions sites\n- Turned off the Pop Blocker\n- Added to Compatibility View\n"
		}

	];

	var $amedisysApps = [
		{
			appID: 0,
			application: "HomeCare HomeBase",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 1,
			application: "Outlook",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 2,
			application: "Citrix",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 3,
			application: "Other",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 4,
			application: "Windows",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 5,
			application: "PointCare",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 6,
			application: "AMS2",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 7,
			application: "McAfee",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 8,
			application: "Laptor",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 9,
			application: "POC Setup",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 10,
			application: "Non-POC Setup",
			callReason:"",
			resolutionSteps:""
		},
		{
			appID: 11,
			application: "Absolute",
			callReason:"Data Freeze",
			resolutionSteps:""
		},
		{
			appID: 12,
			application: "Password Reset",
			callReason:"",
			resolutionSteps:"Reset Password\nUser Verified Resolution"
		},
		{
			appID: 13,
			application: "Academy",
			callReason:"",
			resolutionSteps:""
		}
	];

var $infinity = ["0411","0412","0417","0419","0420","0421","464","5423","5435","5442","5445","5449","5452","5480","5482","5483","5484","5485","5486",
				"5487","5488","5489","5490","5491","5492","5493","5494","5495","5496","5497","5498"];

var $amedcApps =[
		{
			appID: 0,
			application: "Network" ,
			summary: "Password Reset",
			callReason:"User requests a network password reset",
			resolutionSteps:["User's password is expired","Verified user in HCHB", "Reset user's password", "Provided user with temporary password", "Verified access"]
		},
		{
			appID: 1,
			application: "MaaS360",
			summary:"",
			callReason:"Install/enroll device",
			resolutionSteps:["Verified user through HCHB","Ensured device has active Google account","Walked user through Play Store", "Had user install MaaS360 for Android", "Installed MaaS360 Docs",
				"Installed MaaS360 Secure Viewer", "Installed Secure Editor", "Installed MaaS360 Remote Support", "Opened MaaS360", "Entered Amedisys as Corporate Identifier",
				"Entered Amedisys email address", "Tapped on continue", "Entered User ID (first.last)", "Entered network password", "Set device ownership as Corporate", "Tapped on continue", "Accepted Terms & Conditions",
				"Activated device administrator", "User set MaaS360 passcode", "Confirmed passcode"]
		},
		{
			appID: 2,
			application: "MaaS360",
			summary:"update Network Password",
			callReason:"updated network password within MaaS360",
			resolutionSteps:["Verified user through HCHB", "Advised user to go to MaaS360", "Settings -> Menu -> MaaS360 account", "Verified update was successful by checking email"]
		},
		{
			appID: 3,
			application: "Other",
			summary:"",
			callReason:"",
			resolutionSteps:[""]
		},
		{
			appID: 4,
			application: "Tablet",
			summary:"Setup",
			callReason:"User requesting new device be setup",
			resolutionSteps:["Changed device password", "Logged in to MaaS360", "Configured email","Logged in to PointCare", "Verified access"]
		},
		{
			appID: 5,
			application: "PC",
			summary: "Valet to Production",
			callReason: "User requests valet to production environment in PointCare",
			resolutionSteps: ["Verified user's DOB in HCHB", "Opened PointCare","Chose Manage Accounts and Add Account from log in page ellipsis on PointCare login screen","Entered Server, User ID, Setup code, and New Password", "Validated user", "Chose valet from Amedisys server", "Installed PointCare production", "Reopened PointCare", "Entered in setup code and validated", "User logged in with new password", "Performed Renew", "Performed Synchronize", "Performed Selective Refresh", "Verified proper operation and access of PointCare"]
		}

];
