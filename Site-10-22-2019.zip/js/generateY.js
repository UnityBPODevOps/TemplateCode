function reset() {
var document.getElementById("reset").reset();
}

$("input[name=yumaTicketType]").click(function() {
  var $contract = $(".contract.active").html();
  if ($(this).val() == "2") {
    $(".yumaIncident").removeClass("hidden");
    $("textarea[class*='" + $contract + "']").expanding();
  } else {
    $(".yumaIncident").addClass("hidden");
    $("textarea[class*'" + $contract + "']").expanding();
  }

});

function Yuma() {
  var $infoMissing = false;
  var $contract = $(".contract.active").html();
  var $name = $("#yumaName").val();
  var $phone = $("#yumaPhone").val();
  var $device = $("#yumaDevice").val();
  var $location = $("#yumaLocation").val();
  var $department = $("#yumaDepartment").val();
  var $login = $("#yumaLogin").val();
  var $reason = $("#yumaReason").val();
  var $steps = $("#yumaSteps").val();
  var $mrn = $("#yumaMRN").val();
  var $ptName = $("#yumaPtName").val();
  var $dob = $("#yumaDOB").val();
  var $affected = $("#yumaAffected").val();
  var $start = $("#yumaStart").val();
  var $worked = $("#yumaWorked").val();
  var $changed = $("#yumaChanged").val();
  var $error = $("#yumaErrorMessage").val();

	var $template = "Name: " + $name + "\r\n";
  $template += "Phone: " + $phone + "\r\n";
  $template += "Device" + "/" + "Phone Impacted: " + $device + "\r\n";
  $template += "Location: " + $location + "\r\n";
  $template += "Department: " + $department + "\r\n";
  $template += "Login Dept: " + $login + "\r\n";
  $template += "--------------------------Reason for Call----------------------------\r\n";
  $template += $reason + "\r\n";
  $template += "--------------------------Steps to Resolve---------------------------\r\n";
  $template += $steps + "\r\n";
  $template += "--------------------------PHI Info---------------------------\r\n";
  $template += "MRN: " + $mrn + "\r\n";
  $template += "Name: " + $ptName + "\r\n";
  $template += "DOB: " + $dob + "\r\n";
  
  if ($("input[name=yumaTicketType]:checked").val() == "2") {
    $template += "-------------Incident Questions-----------\r\n";
    if ($affected != "") $template += "Who is this affecting? " + $affected + " \r\n";
    if ($start != "") $template += "When did this start? " + $start + " \r\n";
    if ($worked != "") $template += "Did this work before? " + $worked + " \r\n";
    if ($changed != "") $template += "Has anything changed since it last worked? " + $changed + " \r\n";
    if ($error != "") $template += "List any error messages: " + $error + " \r\n";

  }
  $("#yumaTemplate").val($template);
  $("#yumaTemplate").select();
}