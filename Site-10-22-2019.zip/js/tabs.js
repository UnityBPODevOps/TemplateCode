function openContract(evt, Technical) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Technical).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, AmedC) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(AmedC).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, AmedT) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(AmedT).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Axia) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Axia).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, CodeC) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(CodeC).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Epic) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Epic).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Graham) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Graham).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Mobility) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Mobility).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Presbyterian) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Presbyterian).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Valley) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Valley).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, Visiting) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("form-horizontal hidden");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(Visiting).style.display = "block";
  evt.currentTarget.className += "active";
}

function openContract(evt, YRMC) {
	var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
  tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
  tablinks[i].className.replace("active", "");
  }
  document.getElementById(YRMC).style.display = "block";
  evt.currentTarget.className += "active";
}